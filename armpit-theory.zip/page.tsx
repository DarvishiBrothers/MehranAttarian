import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

// HeadMetadata component for SEO
function HeadMetadata({ lang, title, description, keywords }: { lang: string; title: string; description: string; keywords: string }) {
  return (
    <>
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      <meta name="language" content={lang} />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      {/* English fonts */}
      <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&family=Manrope:wght@400;700&display=swap"
        rel="stylesheet"
      />
      {/* Persian fonts */}
      <link
        href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css"
        rel="stylesheet"
      />
    </>
  );
}

type Language = "en" | "fa";

const Content = {
  en: {
    siteTitle: "The Armpit Theory as an Indicator of Personal Hygiene and Body Self-Acceptance",
    metaDescription:
      "An artistic–scientific exploration of how a small gesture reveals our self-awareness.",
    heroTitle: "The Armpit Theory as an Indicator of Personal Hygiene and Body Self-Acceptance",
    heroSubtitle:
      "An artistic-scientific exploration of how a small gesture reveals our self-awareness.",
    readAbstract: "Read Abstract",
    abstractTitle: "Abstract",
    abstractText:
      "The Armpit Theory examines how everyday gestures involving the armpit—such as posture adjustments, protective positioning, or casual exposure—reflect underlying psychological states of self-acceptance and hygiene awareness. Through a mixed-methods approach combining qualitative observations and simple quantitative proxies (e.g., comfort in public settings, frequency of concealment behaviors), this study explores the intersection of body comfort, cleanliness, and identity. We investigate whether bodily ease correlates with higher hygiene consciousness and a more tolerant self-perception, while also considering cultural norms and gender expectations that modulate these signals. The theory does not reduce dignity to a gesture; instead, it invites us to consider how subtle bodily cues can serve as gentle mirrors to our inner narratives about care, discipline, and belonging.",
    introTitle: "Introduction",
    introText:
      "Bodies speak even when we remain silent. A slight shift of the shoulder, the decision to keep an arm close, or the choice to uncover is loaded with meaning. This study listens closely to those micro-gestures, particularly those centered on the armpit—a region rich with nerve endings, cultural taboos, and personal histories. We consider how hygiene and self-acceptance entwine to shape the way we move through the world.",
    methodTitle: "Research Method",
    methodIntro:
      "We compared behaviors across two cohorts while tracking variables of comfort, concealment, and confidence.",
    methodGroups: {
      public: "Public Figures (singers, performers)",
      private: "Private Subjects (adult actors)",
    },
    findingsTitle: "Findings",
    findingsIntro:
      "We observed consistent patterns: comfort with visibility correlates with reported hygiene awareness and body confidence.",
    quote1: "The body speaks even when we hide it.",
    discussionTitle: "Discussion",
    discussionText:
      "Small gestures can act as windows into broader narratives of self-regard. When the body feels accepted, it often moves with fewer defenses. Hygiene practices, in turn, support this ease, creating a feedback loop between cleanliness and confidence.",
    conclusionTitle: "Conclusion",
    conclusionText:
      "The Armpit Theory offers a sensitive lens through which to consider the choreography of everyday gestures. It reminds us that acceptance is embodied and that care—of self and others—can be read in the soft language of posture and touch.",
    takeaways: [
      {
        title: "Hygiene awareness",
        subtitle: "Clean body, clear mind",
        desc: "Consistent care routines support a quieter inner dialogue and more composed public presence.",
      },
      {
        title: "Self-acceptance",
        subtitle: "Comfort with visibility",
        desc: "When we inhabit our bodies with fewer judgments, gestures relax and communication softens.",
      },
      {
        title: "Personal discipline",
        subtitle: "Reflection of internal order",
        desc: "Small, intentional acts can anchor attention and bring a gentle rhythm to daily life.",
      },
    ],
    authorTitle: "Author",
    authorBio:
      "Mehran Attarian is a researcher exploring the crossroads of body, identity, and everyday rituals. This project blends psychology, design, and subtle behavioral observation.",
    contact: "Contact / Publications",
    footerCopyright: "© 2025 Mehran Attarian. All rights reserved.",
    keywords:
      "Psychology, Hygiene, Body Awareness, Minimalism, Art & Science, Self-Acceptance, Clean Design, Human Behavior",
    toggleEn: "English",
    toggleFa: "فارسی",
    lightMode: "Light",
    darkMode: "Dark",
    ambientOn: "Ambient",
    ambientOff: "No ambient",
    chartComfort: "Comfort with Visibility",
    chartConfidence: "Body Confidence",
    chartHygiene: "Hygiene Awareness",
  },
  fa: {
    siteTitle: "نظریهٔ زیر بغل به‌عنوان شاخص بهداشت فرد و خودپذیری بدنی",
    metaDescription:
      "کاوشی هنری–علمی دربارهٔ اینکه چگونه یک رفتار کوچک می‌تواند میزان آگاهی ما از بدن را نشان دهد.",
    heroTitle: "نظریهٔ زیر بغل به‌عنوان شاخص بهداشت فرد و خودپذیری بدنی",
    heroSubtitle:
      "کاوشی هنری–علمی دربارهٔ اینکه چگونه یک رفتار کوچک می‌تواند میزان آگاهی ما از بدن را نشان دهد.",
    readAbstract: "خواندن چکیده",
    abstractTitle: "چکیده",
    abstractText:
      "نظریهٔ زیر بغل بررسی می‌کند که چگونه حرکات روزمره مرتبط با این ناحیه—مانند تنظیم وضعیت بدن، موقعیت‌گیری‌های محافظتی، یا نمایش آرام— بازتاب‌دهندهٔ وضعیت‌های روانی خودپذیری و آگاهی بهداشتی است. این پژوهش با روش آمیخته (ترکیب مشاهده‌های کیفی و شاخص‌های کمی ساده مانند احساس راحتی در فضاهای عمومی و فراوانی رفتارهای پنهان‌سازی) به بررسی پیوند راحتی بدنی، پاکیزگی و هویت می‌پردازد. پرسش اصلی این است: آیا راحتی بدن با خودپذیری و توجه بیشتر به بهداشت همراه است؟ همچنین هنجارهای فرهنگی و انتظارات جنسیتی که این نشانه‌ها را شکل می‌دهند، مد نظر قرار می‌گیرد. این نظریه شرافت انسانی را به یک ژست کاهش نمی‌دهد؛ بلکه دعوتی است به دقت در زبان ظریف بدن به‌عنوان آینه‌ای برای روایت‌های درونیِ مراقبت، نظم و تعلق.",
    introTitle: "مقدمه",
    introText:
      "بدن، حتی وقتی سکوت می‌کنیم، سخن می‌گوید. کمی جابجا شدن شانه، تصمیم به نزدیک نگه داشتن بازو، یا انتخاب نمایاندن آرام، همگی پرمعنا هستند. این پژوهش با دقت به این ریزحرکات گوش می‌سپارد؛ به‌ویژه در ناحیهٔ زیر بغل که سرشار از پایانه‌های عصبی، تابوهای فرهنگی و خاطرات شخصی است. می‌پرسیم بهداشت و خودپذیری چگونه در هم می‌تنند تا شیوهٔ حضور ما در جهان را شکل دهند.",
    methodTitle: "روش پژوهش",
    methodIntro:
      "رفتارها در دو گروه مقایسه شد و متغیرهای راحتی، پنهان‌سازی و اعتمادبه‌نفس پیگیری گردید.",
    methodGroups: {
      public: "افراد مشهور (خوانندگان، اجراکنندگان)",
      private: "افراد غیر مشهور (بازیگران بزرگسال)",
    },
    findingsTitle: "یافته‌ها",
    findingsIntro:
      "الگوهای پایداری مشاهده شد: راحتی در نمایش با آگاهی بهداشتی و اعتمادبه‌نفس بدنی همبستگی دارد.",
    quote1: "بدن حتی وقتی پنهانش می‌کنیم هم حرف می‌زند.",
    discussionTitle: "بحث",
    discussionText:
      "ژست‌های کوچک می‌توانند پنجره‌ای به روایت‌های بزرگ‌ترِ خودبینش باشند. وقتی بدن پذیرفته می‌شود، اغلب با دفاع کمتری حرکت می‌کند. مراقبت‌های بهداشتی به نوبهٔ خود این آسایش را پشتیبانی می‌کنند و حلقهٔ بازخوردی میان پاکیزگی و اعتماد شکل می‌گیرد.",
    conclusionTitle: "نتیجه‌گیری",
    conclusionText:
      "نظریهٔ زیر بغل، عدسی حساسی برای دیدن کُریوگرافیِ ژست‌های روزمره ارائه می‌کند. به ما یادآوری می‌کند که پذیرش، تجسد یافته و مراقبت—از خود و دیگران—در زبان نرمِ وضعیت و لمس قابل خواندن است.",
    takeaways: [
      {
        title: "آگاهی بهداشتی",
        subtitle: "تن پاک، ذهن آرام",
        desc: "روندهای ثابت مراقبت، گفت‌وگوی درونی را آرام‌تر و حضور عمومی را متین‌تر می‌سازند.",
      },
      {
        title: "خودپذیری",
        subtitle: "راحتی با نمایان بودن",
        desc: "هنگامی که بدن را با قضاوت کمتری می‌پذیریم، حرکات آرام و ارتباط نرم می‌شود.",
      },
      {
        title: "انضباط شخصی",
        subtitle: "بازتاب نظم درونی",
        desc: "کنش‌های کوچک و آگاهانه می‌توانند توجه را لنگر بیندازند و ریتمی ملایم به زندگی روزمره ببخشند.",
      },
    ],
    authorTitle: "دربارهٔ نویسنده",
    authorBio:
      "مهران عطاریان پژوهشگری است که در تقاطع بدن، هویت و آیین‌های روزمره کار می‌کند. این پروژه روان‌شناسی، طراحی و مشاهدهٔ رفتارهای ظریف را درهم می‌آمیزد.",
    contact: "تماس / مقالات",
    footerCopyright: "© ۱۴۰۴ مهران عطاریان. تمامی حقوق محفوظ است.",
    keywords:
      "روان‌شناسی، بهداشت، آگاهی بدنی، مینیمالیسم، هنر و علم، خودپذیری، طراحی تمیز، رفتار انسانی",
    toggleEn: "English",
    toggleFa: "فارسی",
    lightMode: "روشن",
    darkMode: "تاریک",
    ambientOn: "صوت محیطی",
    ambientOff: "بی‌صدا",
    chartComfort: "راحتی با نمایان بودن",
    chartConfidence: "اعتمادبه‌نفس بدنی",
    chartHygiene: "آگاهی بهداشتی",
  },
};

function useScrollProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      const p = max > 0 ? doc.scrollTop / max : 0;
      setProgress(p);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return progress;
}

function usePrefersReducedMotion() {
  const [prefers, setPrefers] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setPrefers(!!mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return prefers;
}

function useAmbientBreath(active: boolean, lang: Language) {
  const audioRef = useRef<{ ctx?: AudioContext; osc?: OscillatorNode; gain?: GainNode; raf?: number } | null>(null);

  useEffect(() => {
    if (!active) {
      if (audioRef.current?.ctx) {
        audioRef.current.ctx.close().catch(() => {});
        cancelAnimationFrame(audioRef.current.raf || 0);
        audioRef.current = null;
      }
      return;
    }
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = lang === "fa" ? 0.18 : 0.22; // slower for Persian, slightly faster for English
    gain.gain.value = 0.0006; // very low volume
    osc.connect(gain).connect(ctx.destination);
    osc.start();

    let t = 0;
    const base = 0.0006;
    const amp = 0.00045;

    const loop = () => {
      t += 0.015;
      const breath = base + amp * (0.5 + 0.5 * Math.sin(t));
      gain.gain.setTargetAtTime(breath, ctx.currentTime, 0.08);
      audioRef.current!.raf = requestAnimationFrame(loop);
    };
    loop();

    audioRef.current = { ctx, osc, gain };
    return () => {
      osc.stop();
      ctx.close().catch(() => {});
      cancelAnimationFrame(audioRef.current?.raf || 0);
      audioRef.current = null;
    };
  }, [active, lang]);
}

function classNames(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

export default function HomePage() {
  const [lang, setLang] = useState<Language>("en");
  const [dark, setDark] = useState(false);
  const [ambient, setAmbient] = useState(false);
  const progress = useScrollProgress();
  const reduceMotion = usePrefersReducedMotion();
  const t = Content[lang];
  const rtl = lang === "fa";

  useEffect(() => {
    if (dark) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  }, [dark]);

  useAmbientBreath(ambient, lang);

  // Simple chart data
  const chartData = useMemo(
    () => [
      { en: "Public Figures", fa: "افراد مشهور", Comfort: 78, Confidence: 72, Hygiene: 81 },
      { en: "Private Subjects", fa: "افراد غیر مشهور", Comfort: 62, Confidence: 58, Hygiene: 66 },
    ],
    []
  );

  const [inView, setInView] = useState<Record<string, boolean>>({});
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          setInView((prev) => ({ ...prev, [e.target.id]: e.isIntersecting }));
        });
      },
      { threshold: 0.15 }
    );
    const ids = ["hero", "abstract", "intro", "method", "findings", "discussion", "conclusion", "author", "footer"];
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  return (
    <div className={classNames("min-h-screen bg-gradient-to-b from-cream-50 to-beige-50 text-slate-800 dark:from-neutral-950 dark:to-neutral-900 dark:text-slate-100 transition-colors", rtl && "fa-ui")} dir={rtl ? "rtl" : "ltr"}>
      <HeadMetadata lang={lang} title={t.siteTitle} description={t.metaDescription} keywords={t.keywords} />

      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-neutral-900/60 border-b border-slate-200/70 dark:border-white/10">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="font-semibold tracking-tight text-slate-700 dark:text-slate-200">
            {lang === "en" ? "The Armpit Theory" : "نظریهٔ زیر بغل"}
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2">
              <button
                onClick={() => setLang("en")}
                className={classNames(
                  "px-3 py-1.5 rounded-full text-sm transition border",
                  lang === "en"
                    ? "bg-pink-100 border-pink-200 text-pink-700 dark:bg-pink-900/30 dark:border-pink-800 dark:text-pink-200"
                    : "bg-white/60 border-transparent hover:bg-pink-50 dark:bg-neutral-800/50 dark:hover:bg-neutral-700/50"
                )}
                aria-label="Switch to English"
              >
                🇬🇧 {t.toggleEn}
              </button>
              <button
                onClick={() => setLang("fa")}
                className={classNames(
                  "px-3 py-1.5 rounded-full text-sm transition border",
                  lang === "fa"
                    ? "bg-pink-100 border-pink-200 text-pink-700 dark:bg-pink-900/30 dark:border-pink-800 dark:text-pink-200"
                    : "bg-white/60 border-transparent hover:bg-pink-50 dark:bg-neutral-800/50 dark:hover:bg-neutral-700/50"
                )}
                aria-label="Switch to Persian"
              >
                🇮🇷 {t.toggleFa}
              </button>
            </div>
            <button
              onClick={() => setDark((d) => !d)}
              className="px-3 py-1.5 rounded-full text-sm border bg-white/60 border-transparent hover:bg-neutral-50 dark:bg-neutral-800/50 dark:hover:bg-neutral-700/50"
              aria-label="Toggle theme"
            >
              {dark ? t.lightMode : t.darkMode}
            </button>
            <button
              onClick={() => setAmbient((a) => !a)}
              className={classNames(
                "px-3 py-1.5 rounded-full text-sm border transition",
                ambient
                  ? "bg-emerald-100 border-emerald-200 text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-800 dark:text-emerald-200"
                  : "bg-white/60 border-transparent hover:bg-emerald-50 dark:bg-neutral-800/50 dark:hover:bg-neutral-700/50"
              )}
              aria-label="Toggle ambient sound"
            >
              {ambient ? t.ambientOn : t.ambientOff}
            </button>
          </div>
        </div>
        {/* Mobile lang switcher */}
        <div className="sm:hidden px-4 pb-3 flex gap-2">
          <button
            onClick={() => setLang("en")}
            className={classNames(
              "flex-1 px-3 py-2 rounded-lg text-sm transition border",
              lang === "en"
                ? "bg-pink-100 border-pink-200 text-pink-700 dark:bg-pink-900/30 dark:border-pink-800 dark:text-pink-200"
                : "bg-white/60 border-transparent hover:bg-pink-50 dark:bg-neutral-800/50 dark:hover:bg-neutral-700/50"
            )}
          >
            🇬🇧 {t.toggleEn}
          </button>
          <button
            onClick={() => setLang("fa")}
            className={classNames(
              "flex-1 px-3 py-2 rounded-lg text-sm transition border",
              lang === "fa"
                ? "bg-pink-100 border-pink-200 text-pink-700 dark:bg-pink-900/30 dark:border-pink-800 dark:text-pink-200"
                : "bg-white/60 border-transparent hover:bg-pink-50 dark:bg-neutral-800/50 dark:hover:bg-neutral-700/50"
            )}
          >
            🇮🇷 {t.toggleFa}
          </button>
        </div>
        {/* Scroll progress bar */}
        <div className="h-1 w-full bg-transparent">
          <div className="h-1 bg-gradient-to-r from-pink-300 to-rose-300 dark:from-pink-800 dark:to-rose-800 transition-all" style={{ width: `${progress * 100}%` }} />
        </div>
      </header>

      <main className="relative">
        {/* Hero */}
        <section id="hero" className="relative overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <div className="absolute -top-32 -left-24 w-96 h-96 bg-pink-200/60 dark:bg-pink-900/30 rounded-full blur-3xl" />
            <div className="absolute top-24 -right-24 w-96 h-96 bg-rose-200/60 dark:bg-rose-900/30 rounded-full blur-3xl" />
            <div className="absolute -bottom-24 left-1/3 w-[28rem] h-[28rem] bg-amber-100/50 dark:bg-amber-900/20 rounded-full blur-[100px]" />
          </div>
          <div className={classNames(
            "mx-auto max-w-6xl px-4 sm:px-6 pt-16 sm:pt-24 pb-12 grid gap-8",
            rtl ? "lg:grid-cols-[1.2fr,1fr]" : "lg:grid-cols-[1fr,1.2fr]"
          )}>
            <div className={classNames(
              "transition duration-700",
              inView.hero ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
            )}>
              <h1 className={classNames(
                "font-bold text-3xl sm:text-4xl lg:text-5xl leading-tight tracking-tight text-slate-800 dark:text-white",
                rtl ? "font-vazirmatn" : "font-inter"
              )}>
                {t.heroTitle}
              </h1>
              <p className={classNames(
                "mt-4 text-lg text-slate-600 dark:text-slate-300",
                rtl ? "font-vazirmatn" : "font-manrope"
              )}>
                {t.heroSubtitle}
              </p>
              <a
                href="#abstract"
                className="inline-flex items-center gap-2 mt-6 px-5 py-2.5 rounded-full bg-pink-600 text-white hover:bg-pink-500 focus:outline-none focus:ring-2 focus:ring-pink-400 transition"
              >
                <span className={rtl ? "font-vazirmatn" : "font-manrope"}>{t.readAbstract}</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className={rtl ? "rotate-180" : ""}>
                  <path d="M5 12h14M13 5l7 7-7 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </a>
            </div>
            <div className={classNames(
              "relative flex items-center justify-center transition delay-150 duration-700",
              inView.hero ? "opacity-100 scale-100" : "opacity-0 scale-95"
            )}>
              {/* Artistic minimal SVG illustration ( armpit silhouette stylized ) */}
              <div className="relative w-full max-w-md aspect-[4/3] rounded-2xl border border-pink-100 dark:border-white/10 bg-white/60 dark:bg-neutral-900/40 shadow-sm overflow-hidden">
                <svg viewBox="0 0 400 300" className="w-full h-full opacity-80">
                  <defs>
                    <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#fbcfe8" />
                      <stop offset="100%" stopColor="#fde68a" />
                    </linearGradient>
                  </defs>
                  <rect x="0" y="0" width="400" height="300" fill="url(#g1)" opacity="0.2" />
                  <path d="M200 40 C 270 50, 310 120, 300 190 C 290 250, 240 280, 200 280 C 160 280, 110 250, 100 190 C 90 120, 130 50, 200 40 Z" fill="#fb7185" opacity="0.1" />
                  <path d="M180 90 C 220 110, 240 140, 240 170 C 240 210, 210 240, 180 240 C 150 240, 120 210, 120 170 C 120 140, 140 110, 180 90 Z" fill="#f472b6" opacity="0.18" />
                </svg>
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-white/80 to-transparent dark:from-neutral-900/60">
                  <p className={classNames("text-xs text-slate-600 dark:text-slate-300", rtl ? "font-vazirmatn" : "font-manrope")}>
                    {lang === "en"
                      ? "Minimal line-art suggesting warmth, breath, and gentle exposure."
                      : "خط‌های مینیمال نشان‌دهندهٔ گرما، تنفس و نمایش آرام."}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Abstract */}
        <section id="abstract" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
          <div className={classNames(
            "grid gap-8 md:grid-cols-2 transition duration-700",
            inView.abstract ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          )}>
            <div className="rounded-2xl border border-pink-100 dark:border-white/10 bg-white/60 dark:bg-neutral-900/40 shadow-sm p-6">
              <h2 className={classNames("text-2xl font-semibold mb-4 text-slate-800 dark:text-white", rtl ? "font-vazirmatn" : "font-inter")}>{t.abstractTitle}</h2>
              <p className={classNames("leading-relaxed text-slate-700 dark:text-slate-200", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{t.abstractText}</p>
            </div>
            <div className="rounded-2xl border border-pink-100 dark:border-white/10 bg-white/60 dark:bg-neutral-900/40 shadow-sm p-6">
              <h2 className={classNames("text-2xl font-semibold mb-4 text-slate-800 dark:text-white", rtl ? "font-vazirmatn" : "font-inter")}>خلاصه</h2>
              <p className={classNames("leading-relaxed text-slate-700 dark:text-slate-200", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{Content.fa.abstractText}</p>
            </div>
          </div>
        </section>

        {/* Introduction */}
        <section id="intro" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
          <div className={classNames(
            "grid md:grid-cols-2 gap-8 items-center transition duration-700",
            inView.intro ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          )}>
            <div className="space-y-4">
              <h3 className={classNames("text-xl font-semibold text-slate-800 dark:text-white", rtl ? "font-vazirmatn" : "font-inter")}>{t.introTitle}</h3>
              <p className={classNames("text-slate-700 dark:text-slate-200 leading-relaxed", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{t.introText}</p>
            </div>
            <div className="relative h-64 rounded-2xl border border-pink-100 dark:border-white/10 bg-gradient-to-br from-rose-50 to-amber-50 dark:from-neutral-900/60 dark:to-neutral-900/30 overflow-hidden">
              <div className="absolute inset-0 opacity-30">
                <svg viewBox="0 0 400 300" className="w-full h-full">
                  <path d="M40 240 Q 120 160, 200 220 T 360 200" stroke="#f43f5e" strokeWidth="3" fill="none" strokeLinecap="round" />
                  <path d="M40 200 Q 120 120, 200 180 T 360 160" stroke="#fb7185" strokeWidth="2" fill="none" strokeLinecap="round" />
                  <path d="M40 160 Q 120 100, 200 140 T 360 120" stroke="#f472b6" strokeWidth="2" fill="none" strokeLinecap="round" />
                </svg>
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center px-4">
                  <div className="text-5xl mb-2">🌿</div>
                  <p className={classNames("text-sm text-slate-600 dark:text-slate-300", rtl ? "font-vazirmatn" : "font-manrope")}>
                    {lang === "en"
                      ? "A soft curve traces confidence and ease."
                      : "خمی نرمی که راحتی و اعتماد را می‌کشد."}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Method */}
        <section id="method" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
          <div className={classNames(
            "transition duration-700",
            inView.method ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          )}>
            <h3 className={classNames("text-2xl font-semibold mb-4 text-slate-800 dark:text-white", rtl ? "font-vazirmatn" : "font-inter")}>{t.methodTitle}</h3>
            <p className={classNames("text-slate-700 dark:text-slate-200 mb-6", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{t.methodIntro}</p>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="rounded-2xl border border-pink-100 dark:border-white/10 bg-white/60 dark:bg-neutral-900/40 p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center">
                    <span className="text-pink-600 dark:text-pink-300">🎤</span>
                  </div>
                  <h4 className={classNames("font-semibold text-slate-800 dark:text-white", rtl ? "font-vazirmatn" : "font-inter")}>{t.methodGroups.public}</h4>
                </div>
                <ul className={classNames("text-sm text-slate-700 dark:text-slate-200 space-y-2", rtl ? "font-vazirmatn list-inside list-disc" : "font-manrope")}>
                  <li>{lang === "en" ? "Comfort scores measured in live performances" : "اندازه‌گیری نمرهٔ راحتی در اجراهای زنده"}</li>
                  <li>{lang === "en" ? "Gesture frequency correlated with posture openness" : "همبستگی فراوانی ژست با گشودگی وضعیت"}</li>
                  <li>{lang === "en" ? "Media appearances analyzed for concealment behaviors" : "تحلیل حضور رسانه‌ای برای رفتارهای پنهان‌سازی"}</li>
                </ul>
              </div>
              <div className="rounded-2xl border border-pink-100 dark:border-white/10 bg-white/60 dark:bg-neutral-900/40 p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center">
                    <span className="text-pink-600 dark:text-pink-300">🎭</span>
                  </div>
                  <h4 className={classNames("font-semibold text-slate-800 dark:text-white", rtl ? "font-vazirmatn" : "font-inter")}>{t.methodGroups.private}</h4>
                </div>
                <ul className={classNames("text-sm text-slate-700 dark:text-slate-200 space-y-2", rtl ? "font-vazirmatn list-inside list-disc" : "font-manrope")}>
                  <li>{lang === "en" ? "Controlled workshops recording posture changes" : "کارگاه‌های کنترل‌شده برای ثبت تغییرات وضعیت"}</li>
                  <li>{lang === "en" ? "Self-reported hygiene routines and ease of exposure" : "خودگزارش روتین‌های بهداشتی و راحتی نمایش"}</li>
                  <li>{lang === "en" ? "Behavioral coding of arm positioning and touch" : "کدگذاری رفتاری جایگیری و لمس بازو"}</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Findings with Chart */}
        <section id="findings" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
          <div className={classNames(
            "transition duration-700",
            inView.findings ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          )}>
            <h3 className={classNames("text-2xl font-semibold mb-4 text-slate-800 dark:text-white", rtl ? "font-vazirmatn" : "font-inter")}>{t.findingsTitle}</h3>
            <p className={classNames("text-slate-700 dark:text-slate-200 mb-6", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{t.findingsIntro}</p>
            <div className="rounded-2xl border border-pink-100 dark:border-white/10 bg-white/60 dark:bg-neutral-900/40 p-6 shadow-sm">
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.1} />
                  <XAxis
                    dataKey={rtl ? "fa" : "en"}
                    tick={{ fill: "#db2777", fontWeight: "600", fontFamily: rtl ? "Vazirmatn" : "Inter" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: "#db2777", fontWeight: "600", fontFamily: rtl ? "Vazirmatn" : "Inter" }}
                    axisLine={false}
                    tickLine={false}
                    domain={[40, 100]}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: rtl ? "#fce7f3" : "#fef2f2", borderRadius: 8, border: "none" }}
                    labelStyle={{ fontWeight: "bold", fontFamily: rtl ? "Vazirmatn" : "Inter" }}
                    itemStyle={{ fontFamily: rtl ? "Vazirmatn" : "Inter" }}
                    formatter={(value: number, name: string) => [value, t[`chart${name}` as keyof typeof t]]}
                  />
                  <Line
                    type="monotone"
                    dataKey="Comfort"
                    stroke="#ec4899"
                    strokeWidth={3}
                    dot={{ r: 5, fill: "#f9a8d4" }}
                    activeDot={{ r: 7 }}
                    isAnimationActive={!reduceMotion}
                  />
                  <Line
                    type="monotone"
                    dataKey="Confidence"
                    stroke="#db2777"
                    strokeWidth={3}
                    dot={{ r: 5, fill: "#be185d" }}
                    activeDot={{ r: 7 }}
                    isAnimationActive={!reduceMotion}
                  />
                  <Line
                    type="monotone"
                    dataKey="Hygiene"
                    stroke="#f43f5e"
                    strokeWidth={3}
                    dot={{ r: 5, fill: "#f87171" }}
                    activeDot={{ r: 7 }}
                    isAnimationActive={!reduceMotion}
                  />
                </LineChart>
              </ResponsiveContainer>
              <p className={classNames("mt-4 text-center text-sm text-slate-600 dark:text-slate-300", rtl ? "font-vazirmatn" : "font-manrope")}> 
                {lang === "en"
                  ? "Comfort correlates with cleanliness and body confidence."
                  : "راحتی در نمایش بدن با تمیزی و اعتمادبه‌نفس بدنی همبستگی دارد."}
              </p>
            </div>
          </div>
        </section>

        {/* Discussion */}
        <section id="discussion" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
          <div className={classNames(
            "text-center transition duration-700",
            inView.discussion ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          )}>
            <blockquote className={classNames(
              "text-3xl font-extrabold italic mb-6 text-pink-600 dark:text-pink-400",
              rtl ? "font-vazirmatn" : "font-inter"
            )}>
              “{t.quote1}”
            </blockquote>
            <p className={classNames("max-w-3xl mx-auto text-lg text-slate-700 dark:text-slate-200 leading-relaxed", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{t.discussionText}</p>
          </div>
        </section>

        {/* Conclusion */}
        <section id="conclusion" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
          <h3 className={classNames("text-2xl font-semibold mb-8 text-slate-800 dark:text-white text-center", rtl ? "font-vazirmatn" : "font-inter")}>{t.conclusionTitle}</h3>
          <p className={classNames("max-w-4xl mx-auto mb-12 text-center text-slate-700 dark:text-slate-200 leading-relaxed", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{t.conclusionText}</p>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {t.takeaways.map(({ title, subtitle, desc }, i) => (
              <div
                key={i}
                className="rounded-2xl border border-pink-100 dark:border-white/10 bg-white/60 dark:bg-neutral-900/40 p-6 shadow-sm flex flex-col"
              >
                <h4 className={classNames("text-lg font-semibold mb-1 text-pink-700 dark:text-pink-300", rtl ? "font-vazirmatn" : "font-inter")}>{title}</h4>
                <h5 className={classNames("text-sm font-medium mb-2 text-pink-500 dark:text-pink-400", rtl ? "font-vazirmatn" : "font-manrope")}>{subtitle}</h5>
                <p className={classNames("text-sm text-slate-700 dark:text-slate-200 flex-grow", rtl ? "font-vazirmatn text-justify" : "font-manrope")}>{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Author Section */}
        <section id="author" className="mx-auto max-w-6xl px-4 sm:px-6 py-12 sm:py-16">
          <h3 className={classNames("text-2xl font-semibold mb-6 text-slate-800 dark:text-white text-center", rtl ? "font-vazirmatn" : "font-inter")}>{t.authorTitle}</h3>
          <div className="flex flex-col md:flex-row items-center gap-6 max-w-4xl mx-auto">
            <img
              src="https://avatars.githubusercontent.com/u/12345678?v=4"
              alt="Mehran Attarian"
              className="w-32 h-32 rounded-full object-cover border-2 border-pink-200 dark:border-pink-700"
              loading="lazy"
            />
            <div className={classNames("text-center md:text-left", rtl ? "font-vazirmatn" : "font-manrope")}> 
              <p className="text-slate-700 dark:text-slate-200 leading-relaxed max-w-xl">
                {t.authorBio}
              </p>
              <a
                href="mailto:mehran.attarian@example.com"
                className="inline-block mt-4 text-pink-600 dark:text-pink-400 hover:underline"
              >
                {t.contact}
              </a>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer id="footer" className="border-t border-slate-200/70 dark:border-white/10 py-6 mt-12 text-center text-sm text-slate-600 dark:text-slate-400">
          <p>{t.footerCopyright}</p>
          <div className="mt-2 flex justify-center gap-4">
            <a href="https://twitter.com/mehranattarian" target="_blank" rel="noopener noreferrer" aria-label="Twitter" className="hover:text-pink-600 dark:hover:text-pink-400 transition">
              Twitter
            </a>
            <a href="https://linkedin.com/in/mehranattarian" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="hover:text-pink-600 dark:hover:text-pink-400 transition">
              LinkedIn
            </a>
            <a href="https://github.com/mehranattarian" target="_blank" rel="noopener noreferrer" aria-label="GitHub" className="hover:text-pink-600 dark:hover:text-pink-400 transition">
              GitHub
            </a>
          </div>
        </footer>
      </main>
    </div>
  );
}
