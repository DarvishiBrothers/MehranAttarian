export const metadata = {
  title: "The Armpit Theory | نظریه زیر بغل",
  description: "A bilingual research website by Mehran Attarian"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa">
      <body>{children}</body>
    </html>
  );
}
